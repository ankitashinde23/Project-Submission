import React from "react";

function Header() {
  return (
    <header>
      <h1>ShapeAI</h1>;
    </header>
  );
}

export default Header;
