import React from "react";

function Boot() {
  return (
    <div className="note">
      <h1>Javascript and React JS</h1>
      <p>
        This is 7 day long Bootcamp of web development with JS and React JS.
      </p>
    </div>
  );
}

export default Boot;
